# R Language

A language package for [R](http://www.r-project.org).
It provides grammars for R script files and R Markdown files. 
