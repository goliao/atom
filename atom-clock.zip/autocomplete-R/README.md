# Autocomplete+ provider for R statistical software for atom text editor

## Method

### A script was made to parse R documentation and a json file was build (perfectible)
see R/scrapeRdoc.R

### Coffeescript parse json and autocomplete R functions (with Autocomplete plus)


## Note
I'm a noob in coffeescript so this package functionalities could be largely improved.

Also, any suggestions are welcome!

Feel free to contribute!

Special thanks to AltraBio Company

## License
Licensed under the [MIT License](https://raw.githubusercontent.com/guillaumechaumet/autocomplete-R/master/LICENSE)
