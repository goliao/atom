---
name: Documentation Help
about: For requesting explanations or changes of our documentation.
title: ''
labels: 'documentation :page_with_curl:'
assignees: ''

---

<!--

Have you read Hydrogen's Code of Conduct ? By filing an issue, you are expected to comply with it, including treating everyone with respect: https://github.com/nteract/hydrogen/blob/master/CODE_OF_CONDUCT.md

Do you want to ask a question ? Are you looking for support? The #hydrogen channel in nteract slack is the best place for getting support. Feel free to ping us on: https://slack.nteract.io

-->

### Description

[Description of the problem]
