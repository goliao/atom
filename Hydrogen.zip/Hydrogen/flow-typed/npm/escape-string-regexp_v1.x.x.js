// flow-typed signature: ed810fce1a8248c9f857e4b34ac68c14
// flow-typed version: 94e9f7e0a4/escape-string-regexp_v1.x.x/flow_>=v0.28.x

declare module 'escape-string-regexp' {
  declare module.exports: (input: string) => string;
}
