import os
from sample import *

def foo():
    return 'bar'

foo()
