import json

def noKwargs():
    return 1

noKwargs()
json.dumps()
