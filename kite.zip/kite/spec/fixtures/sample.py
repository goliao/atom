variable = 10

def hello():
    print("Hello World!")

import os
from os import posixpath
import matplotlib
import json
import posix
import csv
import requests
import subprocess
import boto
import sqlalchemy

engine = sqlalchemy.create_engine()

sqlalchemy.ext.declarative.api.declarative_base

json.dumps()

boto.s3.connection.S3Connection()

posix.chmod
os.mkdir
csv.reader
matplotlib.pyplot.plot()

requests.get()

__builtins__.list

class A:
    def __init__(self, foo):
        self.foo = foo

    def increment(self, n):
        return n + 1

class B(A):
    def __init__(self, foo):
        super(foo)

    def increment(self, n, **kwargs):
        inc = kwargs.delta or 1
        return super(B, self).increment(abc) + inc

    def dummy(self, abc=True, fed, ghi, jkl, mno, pqr, stuv):
        return abc

if True:
    test = B('foo')
else:
    test = A('foo')

test.increment(2, delta=5)
test.increment('bar')
test.increment('baz')
test.increment(False) if True else test.increment(True)

test.dummy()

if __name__ == "__main__":
    hello()

map(filter(123
